export const defaultConfig = [
	{
		groupName: '[Enter Group Name Here]',
		formulas: {

			'[Enter the current formula]': '[Enter the formula to change to]',

		}
	},

	{
		groupName: '[Enter Group Name Here]',
			formulas: {

			'[Enter the current formula]': '[Enter the formula to change to]',

		}
	},
	
	{
		groupName: '[Enter Group Name Here]',
			formulas: {

			'[Enter the current formula]': '[Enter the formula to change to]',

		}
	}
]