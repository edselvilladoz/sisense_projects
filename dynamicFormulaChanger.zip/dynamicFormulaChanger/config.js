export const defaultConfig = [
	{
		groupName: 'Test',
		formulas: {

		'sum([E Commerce.Revenue]) / sum([E Commerce.Cost])': 'sum([E Commerce.Revenue]) / sum([E Commerce.Cost]) * 5',
		'sum([E Commerce.Revenue]) * 3': 'sum([E Commerce.Revenue]) * 5',
		'sum([E Commerce.Cost]) / sum([E Commerce.Quantity])': 'sum([E Commerce.Cost]) / sum([E Commerce.Quantity]) * 5',
		'sum([E Commerce.Cost]) / 2': 'sum([E Commerce.Cost]) * 5',
		'count([E Commerce. Brand ID]) / 2': 'count([E Commerce. Brand ID]) * 5',
		'Growth([E Commerce.Revenue])': 'Growth([E Commerce.Revenue]) * 5',
		'PastQuarter([E Commerce.Revenue])': 'PastQuarter([E Commerce.Revenue]) * 5',
		'sum([E Commerce.Revenue]) / sum([E Commerce.Quantity])': 'sum([E Commerce.Revenue]) / sum([E Commerce.Quantity]) * 5',
		'sum([E Commerce.Revenue]) * 2': 'sum([E Commerce.Revenue]) * 5',


		//aggregations
		'sum': 'avg',
		'count': 'countduplicates',

		}
	},

	{
		groupName: 'Test2',
			formulas: {

		'sum([E Commerce.Revenue]) / sum([E Commerce.Cost])': 'sum([E Commerce.Revenue]) / sum([E Commerce.Cost]) * 1000',
		'sum([E Commerce.Revenue]) * 3': 'sum([E Commerce.Revenue]) * 1000',
		'sum([E Commerce.Cost]) / sum([E Commerce.Quantity])': 'sum([E Commerce.Cost]) / sum([E Commerce.Quantity]) * 1000',
		'sum([E Commerce.Cost]) / 2': 'sum([E Commerce.Cost]) * 1000',
		'count([E Commerce. Brand ID]) / 2': 'count([E Commerce. Brand ID]) * 1000',
		'Growth([E Commerce.Revenue])': 'Growth([E Commerce.Revenue]) * 1000',
		'PastQuarter([E Commerce.Revenue])': 'PastQuarter([E Commerce.Revenue]) * 1000',
		// 'sum([E Commerce.Revenue]) / sum([E Commerce.Quantity])': 'sum([E Commerce.Revenue]) / sum([E Commerce.Quantity]) * 1000',
		// 'sum([E Commerce.Revenue]) * 2': 'sum([E Commerce.Revenue]) * 1000',

		//aggregations
		// 'sum': 'avg',
		// 'count': 'countduplicates',

		}
	}
]