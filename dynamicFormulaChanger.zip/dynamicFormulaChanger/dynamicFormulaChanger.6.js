/*************************************************
// Dynamic Formulas
// Last Modified: 07152019
// Created By: Edsel Villadoz
// Description: This Plug-In will change the formula
	applied to a widget based on the user's group.
**************************************************/
import { defaultConfig } from './config';

prism.run([() => {

	prism.on("dashboardloaded", (el, args) => {
		prism.activeDashboard.widgets.$$widgets.forEach((widget) => {//loop through each widget
			widget.metadata.panels.forEach((panel) => {//loop through each panel
				panel.items.forEach((item) => {//loop through each item

					if(item.jaql && item.jaql.formula){//check for jaql & formula
						defaultConfig.forEach((config) => { //Loop through each config
				  			prism.user.groupsName.forEach((prismGroup) => { //Loop through each user group
				  				if(config.groupName === prismGroup.name) { //Match config to a user group
				  					const newFormula = convertFormula(item.jaql.formula, item.jaql.context);
				  					if(config.formulas[newFormula]){//matches newFormula string with config formulas
				  						item.jaql.formula = revertFormula(config.formulas[newFormula], item.jaql.context);//converts config formulas into usable formula string w dimension IDs
				  					}
				  				}
				  			});		
						});
					}

					if(item.jaql && item.jaql.agg){
						defaultConfig.forEach((config) => { //Loop through each config
				  			prism.user.groupsName.forEach((prismGroup) => { //Loop through each user group
				  				if(config.groupName === prismGroup.name) { //Match config to a user group
				  					const currAgg = item.jaql.agg;
				  					if(config.formulas[currAgg]){//matches newFormula string with config formulas
				  						item.jaql.agg = config.formulas[currAgg];//converts config formulas into usable formula string w dimension IDs
				  					}
				  				}
				  			});		
						});

					}
					
				});
			});

		widget.refresh();
		});
	});	

	function convertFormula(fString, fContext){
		let newFString = fString;
		if(!fContext){
			return fString;
		}
		Object.getOwnPropertyNames(fContext).forEach((item) => {
			newFString = newFString.replace(item, fContext[item].dim);//replace item name with dim
		});
		const isNotFinished = Object.getOwnPropertyNames(fContext).some((item) => {//loops through contexts if multiple objects exist
			return newFString.indexOf(item) >= 0;
		});
		if(isNotFinished){//converts next object in context if it exists
			newFString = convertFormula(newFString, fContext);
		}
		return newFString;//return new formula string with replaced dim
	}

	function revertFormula(fString, fContext){//similar to convertFormula but replaces dim with item name
		let newFString = fString;
		if(!fContext){
			return fString;
		}
		Object.getOwnPropertyNames(fContext).forEach((item) => {
			newFString = newFString.replace(fContext[item].dim, item);//replaces dim with item name
		});
		const isNotFinished = Object.getOwnPropertyNames(fContext).some((item) => {
			return newFString.indexOf(fContext[item].dim) >= 0;
		});
		if(isNotFinished){
			newFString = convertFormula(newFString, fContext);
		}
		return newFString;
	}

  },
]);